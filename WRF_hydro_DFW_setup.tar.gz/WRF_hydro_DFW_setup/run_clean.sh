#!/bin/bash
# Shell script to clean output files from a previous run before starting a new run.
# Usage:  ./run_clean.sh
# Notes:
# VIP!!! Make sure you don't remove anything you may want, particularly long-term accumluation files or restart files!!!!
#
# Contributed by: B. Fersch, Oct. 2013
# Modified by: D. Gochis, Oct. 2013


rm 20*.LSMOUT_DOMAIN*
rm 20*.RTOUT_DOMAIN* 
rm 20*.CHRTOUT* 
rm 20*.CHANOBS* 
rm 20*.LDASOUT_DOMAIN*
rm frxst_pts_out.txt

#Restart files...
rm HYDRO_RST.20* 
rm RESTART.20* 

#Misc. diagnostic files...
rm qstrmvol*
#rm chan_infl*
rm diag_hydro.*
rm std*.txt
rm log.txt
rm wrf*.err wrf*.out

#Bucket Model output files...a
rm GW_*.txt

#2-D Groundwater output files...
#rm *.GW_DOMAIN1 
