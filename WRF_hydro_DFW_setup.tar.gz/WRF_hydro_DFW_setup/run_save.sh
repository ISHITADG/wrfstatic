#!/bin/bash
# Shell script to save files from a previous run before starting a new run.
# Script will also clean up directory in preparation for next run...
# Usage:  ./run_save.sh <save_directory>
# Notes:
#
# Modified by: D. Gochis, Nov. 5, 2014

save_dir=$1

#mkdir $save_dir
cp frxst_pts_out.txt diag_hydro.00000 GW_*txt $save_dir
rm *LSMOUT* diag* std* qstrmvolrt_accum.txt wrf*.err wrf*.out
cp CHANPARM.TBL GENPARM.TBL namelist.hrldas hydro.namelist GWBUCKPARM.TBL SOILPARM.TBL $save_dir
mv 201* $save_dir
mv HYDRO_RST* RESTART* $save_dir
